#property strict
#property version   "1.00"
#property description "Pattern Hunter data bridge. Sends market data only; does not trade."

input string ServerHost = "127.0.0.1";
input uint   ServerPort = 8765;
input int    BarsToSend = 160;
input int    SendIntervalSeconds = 1;
input bool   SendOnNewBar = true;

int socket_handle = INVALID_HANDLE;
datetime last_bar_time = 0;
datetime last_send_time = 0;

bool ConnectServer()
{
   if(socket_handle != INVALID_HANDLE && SocketIsConnected(socket_handle))
      return true;
   if(socket_handle != INVALID_HANDLE)
      SocketClose(socket_handle);
   socket_handle = SocketCreate();
   if(socket_handle == INVALID_HANDLE)
   {
      Print("PatternHunter: SocketCreate failed. Error=", GetLastError());
      return false;
   }
   if(!SocketConnect(socket_handle, ServerHost, ServerPort, 1000))
   {
      Print("PatternHunter: connect failed. Error=", GetLastError());
      SocketClose(socket_handle);
      socket_handle = INVALID_HANDLE;
      return false;
   }
   Print("PatternHunter: connected to ", ServerHost, ":", ServerPort);
   return true;
}

string EscapeJson(string s)
{
   StringReplace(s, "\\", "\\\\");
   StringReplace(s, "\"", "\\\"");
   return s;
}

bool SendPacket()
{
   if(!ConnectServer()) return false;

   MqlRates rates[];
   ArraySetAsSeries(rates, false); // chronological: oldest to newest
   int copied = CopyRates(_Symbol, PERIOD_M1, 0, BarsToSend, rates);
   if(copied < 10)
   {
      Print("PatternHunter: insufficient bars: ", copied);
      return false;
   }

   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick)) return false;

   string json = "{\"type\":\"market\",\"symbol\":\"" + EscapeJson(_Symbol) +
      "\",\"timeframe\":\"M1\",\"bid\":" + DoubleToString(tick.bid, _Digits) +
      ",\"ask\":" + DoubleToString(tick.ask, _Digits) +
      ",\"spread\":" + DoubleToString((tick.ask-tick.bid)/_Point, 1) +
      ",\"bar_time\":\"" + TimeToString(rates[copied-1].time, TIME_DATE|TIME_MINUTES|TIME_SECONDS) +
      "\",\"bars\":[";
   for(int i=0; i<copied; i++)
   {
      if(i>0) json += ",";
      json += "{\"time\":\"" + TimeToString(rates[i].time, TIME_DATE|TIME_MINUTES|TIME_SECONDS) +
         "\",\"open\":" + DoubleToString(rates[i].open, _Digits) +
         ",\"high\":" + DoubleToString(rates[i].high, _Digits) +
         ",\"low\":" + DoubleToString(rates[i].low, _Digits) +
         ",\"close\":" + DoubleToString(rates[i].close, _Digits) +
         ",\"tick_volume\":" + IntegerToString((long)rates[i].tick_volume) + "}";
   }
   json += "]}\n";

   uchar data[];
   int n = StringToCharArray(json, data, 0, WHOLE_ARRAY, CP_UTF8);
   if(n <= 1) return false;
   ArrayResize(data, n-1); // remove terminating zero; keep newline
   int sent = SocketSend(socket_handle, data, ArraySize(data));
   if(sent != ArraySize(data))
   {
      Print("PatternHunter: SocketSend incomplete. sent=",sent," expected=",ArraySize(data),
            " err=",GetLastError());
      SocketClose(socket_handle);
      socket_handle = INVALID_HANDLE;
      return false;
   }
   return true;
}

int OnInit()
{
   EventSetTimer(MathMax(1, SendIntervalSeconds));
   Print("PatternHunter Bridge initialized. Symbol=",_Symbol,
         " Period=",EnumToString((ENUM_TIMEFRAMES)_Period),
         " Server=",ServerHost,":",ServerPort,
         " BarsToSend=",BarsToSend,
         ". No trade functions are present.");
   return INIT_SUCCEEDED;
}

void OnTimer()
{
   datetime current_bar = iTime(_Symbol, PERIOD_M1, 0);
   bool new_bar = (current_bar != 0 && current_bar != last_bar_time);
   bool interval_due = (TimeLocal() - last_send_time >= SendIntervalSeconds);
   if((SendOnNewBar && new_bar) || interval_due)
   {
      if(SendPacket()) last_send_time = TimeLocal();
      if(new_bar) last_bar_time = current_bar;
   }
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   if(socket_handle != INVALID_HANDLE) SocketClose(socket_handle);
}
