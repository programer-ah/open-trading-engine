import json, socket, threading, time, logging
from pathlib import Path
import numpy as np
from .features import live_candle_sequence, dtw_similarity
from .store import Store


class Engine:
    def __init__(self, root, ui_callback=None, host="127.0.0.1", port=8765):
        self.root = Path(root)
        self.store = Store(root)
        self.ui_callback = ui_callback
        self.host = host
        self.port = port
        self.running = False
        self.last_alert = {}
        self.server = None
        self.logger = logging.getLogger("PatternHunter")
        self.packet_count = 0
        self.last_market_time = None
        self.last_symbol = None
        self.last_timeframe = None
        self.last_bar_count = 0
        self.last_price = None
        self.last_telemetry_notice = 0.0
        self._stats_lock = threading.Lock()

    def notify(self, kind, text, payload=None):
        self.logger.info("%s: %s", kind, text)
        if self.ui_callback:
            self.ui_callback(kind, text, payload or {})

    def start(self):
        if self.running:
            return
        self.running = True
        threading.Thread(target=self._serve, daemon=True).start()

    def stop(self):
        self.running = False
        try:
            if self.server:
                self.server.close()
        except Exception:
            pass

    def _serve(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server = srv
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind((self.host, self.port))
            srv.listen(3)
            srv.settimeout(1)
            self.notify("SYSTEM", f"TCP listener ready at {self.host}:{self.port}")
            while self.running:
                try:
                    conn, addr = srv.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break
                self.notify("SYSTEM", f"MT5 client connected: {addr[0]}:{addr[1]}")
                threading.Thread(target=self._client, args=(conn, addr), daemon=True).start()
        except Exception as e:
            self.notify("ERROR", f"Listener error: {e}")
        finally:
            try:
                srv.close()
            except Exception:
                pass

    def _client(self, conn, addr):
        buf = b""
        with conn:
            conn.settimeout(10)
            while self.running:
                try:
                    data = conn.recv(65536)
                except socket.timeout:
                    continue
                except OSError as e:
                    self.notify("ERROR", f"Socket receive error: {e}")
                    break
                if not data:
                    self.notify("SYSTEM", f"MT5 client disconnected: {addr[0]}:{addr[1]}")
                    break
                buf += data
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if not line.strip():
                        continue
                    try:
                        msg = json.loads(line.decode("utf-8"))
                        self.process_message(msg)
                    except Exception as e:
                        self.notify("ERROR", f"Bad data packet: {e}")

    def process_message(self, msg):
        if msg.get("type") != "market":
            self.notify("WARNING", f"Unknown packet type: {msg.get('type')}")
            return

        bars = msg.get("bars")
        symbol = msg.get("symbol", "?")
        timeframe = msg.get("timeframe", "?")
        if not isinstance(bars, list):
            self.notify("WARNING", "Market packet has no valid bars array")
            return

        valid_bars = []
        for b in bars:
            try:
                row = {
                    "time": b.get("time", ""),
                    "open": float(b["open"]),
                    "high": float(b["high"]),
                    "low": float(b["low"]),
                    "close": float(b["close"]),
                    "tick_volume": int(b.get("tick_volume", 0))
                }
                if row["high"] < row["low"]:
                    continue
                valid_bars.append(row)
            except (KeyError, TypeError, ValueError):
                continue

        if len(valid_bars) < 10:
            now = time.time()
            if now - self.last_telemetry_notice > 5:
                self.last_telemetry_notice = now
                self.notify("WARNING", f"Market data received but only {len(valid_bars)} valid bars; at least 10 required")
            return

        with self._stats_lock:
            self.packet_count += 1
            self.last_market_time = time.strftime("%Y-%m-%d %H:%M:%S")
            self.last_symbol = symbol
            self.last_timeframe = timeframe
            self.last_bar_count = len(valid_bars)
            self.last_price = valid_bars[-1]["close"]
            packet_count = self.packet_count
            should_report = (time.time() - self.last_telemetry_notice >= 2.0)
            if should_report:
                self.last_telemetry_notice = time.time()

        if should_report:
            text = (f"دریافت بازار فعال | {symbol} {timeframe} | "
                    f"{len(valid_bars)} کندل | آخرین قیمت: {valid_bars[-1]['close']} | "
                    f"بسته‌های دریافتی: {packet_count}")
            self.notify("MARKET", text, {
                "symbol": symbol, "timeframe": timeframe,
                "bars": len(valid_bars), "price": valid_bars[-1]["close"],
                "packets": packet_count, "bar_time": msg.get("bar_time", "")
            })

        # The EA sends bars in chronological order (oldest -> newest).
        # The newest bar is normally still forming, so compare only closed bars.
        closed = valid_bars[:-1]
        if len(closed) < 8:
            return

        for p in self.store.patterns():
            d = p["descriptor"]
            ref = d.get("sequence_proxy")
            if not ref or len(ref) < 5:
                continue
            ref_len = int(d.get("bar_count", len(ref)))
            if ref_len < 5 or len(closed) < ref_len:
                continue
            window = closed[-ref_len:]
            cur = live_candle_sequence(window, len(ref))
            ref_array = np.asarray(ref, dtype=np.float32).reshape(-1, 4)
            score = dtw_similarity(ref_array, cur)
            key_time = msg.get("bar_time", "")
            key = (p["id"], key_time)
            if score >= float(p["threshold"]) and self.last_alert.get(p["id"]) != key_time:
                self.last_alert[p["id"]] = key_time
                text = f'{p["name"]} ({p["id"]}) similarity {score:.1f}% on {symbol}'
                self.store.event("PATTERN", symbol, p["id"], score, text, {"bar_time": key_time})
                self.notify("PATTERN", text, {
                    "pattern_id": p["id"], "score": score, "symbol": symbol,
                    "timeframe": timeframe, "bar_time": key_time
                })
