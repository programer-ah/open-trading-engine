import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
from pathlib import Path
import shutil, uuid, json, logging, time
import cv2, numpy as np
from .features import image_descriptor, image_candle_sequence
from .engine import Engine

ROOT = Path(__file__).resolve().parent.parent
(ROOT/"Library").mkdir(exist_ok=True)
(ROOT/"logs").mkdir(exist_ok=True)
logging.basicConfig(filename=ROOT/"logs"/"pattern_hunter.log", level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")


class App:
    def __init__(self, root):
        self.root = root
        root.title("Pattern Hunter – Live Pattern Radar")
        root.geometry("1420x900")
        root.minsize(1050, 700)
        self.engine = Engine(ROOT, self.on_event)
        self.image_path = None
        self.tkimg = None
        self.scale = 1.0
        self.offset = (0, 0)
        self.selections = []
        self.start_pt = None
        self.shape = tk.StringVar(value="Rectangle")
        self.status = tk.StringVar(value="در انتظار دریافت اطلاعات بازار...")
        self.connection_text = tk.StringVar(value="DISCONNECTED")
        self.price_text = tk.StringVar(value="—")
        self.market_text = tk.StringVar(value="XAUUSD | M1")
        self.packet_text = tk.StringVar(value="Packets: 0")
        self.last_snapshot = {}
        self._build()
        self.engine.start()
        self.root.after(400, self.refresh_live)
        root.protocol("WM_DELETE_WINDOW", self.close)

    def _build(self):
        header = ttk.Frame(self.root, padding=(10, 8))
        header.pack(fill="x")
        ttk.Label(header, text="PATTERN HUNTER", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Label(header, textvariable=self.connection_text, foreground="#168b58",
                  font=("Segoe UI", 10, "bold")).pack(side="right", padx=12)
        ttk.Label(header, textvariable=self.market_text, font=("Segoe UI", 10)).pack(side="right", padx=12)
        ttk.Label(header, textvariable=self.price_text, font=("Segoe UI", 13, "bold")).pack(side="right", padx=12)
        ttk.Label(header, textvariable=self.packet_text).pack(side="right", padx=12)

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill="both", expand=True, padx=8, pady=4)
        self.live_tab = ttk.Frame(self.tabs, padding=8)
        self.library_tab = ttk.Frame(self.tabs, padding=8)
        self.tabs.add(self.live_tab, text="رادار زنده بازار")
        self.tabs.add(self.library_tab, text="کتابخانه الگوها")

        self._build_live_tab()
        self._build_library_tab()
        footer = ttk.Label(self.root, textvariable=self.status, anchor="w", padding=(10, 5))
        footer.pack(fill="x")

    def _build_live_tab(self):
        upper = ttk.Panedwindow(self.live_tab, orient="horizontal")
        upper.pack(fill="both", expand=True)
        chart_frame = ttk.LabelFrame(upper, text="نمودار زنده MT5", padding=6)
        radar_frame = ttk.LabelFrame(upper, text="رادار تطبیق الگوها", padding=6)
        upper.add(chart_frame, weight=4)
        upper.add(radar_frame, weight=2)

        self.chart = tk.Canvas(chart_frame, bg="#101820", highlightthickness=0, height=430)
        self.chart.pack(fill="both", expand=True)
        self.chart.bind("<Configure>", lambda e: self.draw_live_chart())

        cols = ("name", "score", "threshold", "state")
        self.radar = ttk.Treeview(radar_frame, columns=cols, show="headings", height=15)
        self.radar.heading("name", text="الگو")
        self.radar.heading("score", text="شباهت")
        self.radar.heading("threshold", text="آستانه")
        self.radar.heading("state", text="وضعیت")
        self.radar.column("name", width=155, anchor="w")
        self.radar.column("score", width=75, anchor="center")
        self.radar.column("threshold", width=75, anchor="center")
        self.radar.column("state", width=100, anchor="center")
        self.radar.pack(fill="both", expand=True)
        self.radar.tag_configure("matched", foreground="#13834f")
        self.radar.tag_configure("search", foreground="#a66b00")
        self.radar.tag_configure("notready", foreground="#9b3030")
        self.radar.bind("<<TreeviewSelect>>", self.show_selected_pattern)

        bottom = ttk.Panedwindow(self.live_tab, orient="horizontal")
        bottom.pack(fill="x", expand=False, pady=(8, 0))
        event_frame = ttk.LabelFrame(bottom, text="رویدادها و هشدارها", padding=5)
        info_frame = ttk.LabelFrame(bottom, text="وضعیت موتور", padding=8)
        bottom.add(event_frame, weight=3)
        bottom.add(info_frame, weight=2)
        self.events = tk.Listbox(event_frame, height=8, font=("Consolas", 9))
        self.events.pack(fill="both", expand=True)
        self.engine_info = tk.StringVar(value="موتور هنوز بسته داده دریافت نکرده است.")
        ttk.Label(info_frame, textvariable=self.engine_info, justify="left",
                  wraplength=340).pack(anchor="w", fill="x")
        ttk.Button(info_frame, text="بازخوانی کتابخانه", command=self.refresh_library_list).pack(anchor="w", pady=(8, 0))

    def _build_library_tab(self):
        top = ttk.Frame(self.library_tab, padding=4)
        top.pack(fill="x")
        ttk.Button(top, text="افزودن تصویر", command=self.load_image).pack(side="left", padx=3)
        ttk.Label(top, text="نوع محدوده:").pack(side="left", padx=(15, 3))
        ttk.Combobox(top, textvariable=self.shape,
                     values=["Rectangle", "Square", "Ellipse", "Circle"],
                     state="readonly", width=12).pack(side="left")
        ttk.Button(top, text="حذف آخرین محدوده", command=self.undo).pack(side="left", padx=8)
        ttk.Button(top, text="ذخیره محدوده‌ها", command=self.save).pack(side="left", padx=3)
        ttk.Button(top, text="بازخوانی کتابخانه", command=self.refresh_library_list).pack(side="left", padx=3)
        self.image_canvas = tk.Canvas(self.library_tab, bg="#20242b", highlightthickness=0)
        self.image_canvas.pack(fill="both", expand=True, pady=6)
        self.image_canvas.bind("<ButtonPress-1>", self.mouse_down)
        self.image_canvas.bind("<B1-Motion>", self.mouse_move)
        self.image_canvas.bind("<ButtonRelease-1>", self.mouse_up)
        self.library_list = tk.Listbox(self.library_tab, height=5)
        self.library_list.pack(fill="x")

    def refresh_live(self):
        if not self.root.winfo_exists():
            return
        snap = self.engine.snapshot()
        self.last_snapshot = snap
        if snap["connected"]:
            self.connection_text.set("● CONNECTED")
            self.market_text.set(f'{snap["symbol"]} | {snap["timeframe"]} | {snap["bar_count"]} candles')
            self.price_text.set(f'{snap["price"]:.2f}' if snap["price"] is not None else "—")
            self.packet_text.set(f'Packets: {snap["packets"]}')
            self.engine_info.set(
                f'آخرین دریافت: {snap["market_time"]}\n'
                f'آخرین اسکن: {snap["last_scan_time"] or "در حال آماده‌سازی"}\n'
                f'تعداد کندل دریافتی: {snap["bar_count"]}\n'
                f'تعداد الگوهای ذخیره‌شده: {len(snap["matches"])}\n'
                f'تعداد بسته‌های دریافتی: {snap["packets"]}'
            )
        else:
            self.connection_text.set("○ WAITING FOR MT5")
        self.update_radar(snap.get("matches", []))
        self.draw_live_chart()
        self.root.after(400, self.refresh_live)

    def update_radar(self, matches):
        existing = set(self.radar.get_children())
        seen = set()
        for m in matches:
            name = m.get("name", m.get("id", "Pattern"))
            iid = str(m.get("id", name))
            seen.add(iid)
            score = f'{m.get("score", 0):.1f}%'
            threshold = f'{m.get("threshold", 50):.0f}%'
            state = m.get("state")
            label = {"MATCH": "تطبیق فعال", "SEARCHING": "در حال جست‌وجو",
                     "NOT_READY": m.get("reason", "آماده نیست")}.get(state, state)
            tag = "matched" if state == "MATCH" else ("notready" if state == "NOT_READY" else "search")
            values = (name, score, threshold, label)
            if iid in existing:
                self.radar.item(iid, values=values, tags=(tag,))
            else:
                self.radar.insert("", "end", iid=iid, values=values, tags=(tag,))
        for iid in existing:
            if iid not in seen:
                self.radar.delete(iid)

    def draw_live_chart(self):
        if not hasattr(self, "chart"):
            return
        c = self.chart
        c.delete("all")
        w, h = max(c.winfo_width(), 400), max(c.winfo_height(), 250)
        snap = self.last_snapshot or {}
        bars = snap.get("bars", [])
        pad_l, pad_r, pad_t, pad_b = 58, 12, 24, 30
        if not bars:
            c.create_text(w/2, h/2-10, text="در انتظار کندل‌های MT5 ...",
                          fill="#d3dce6", font=("Segoe UI", 15, "bold"))
            c.create_text(w/2, h/2+20, text="پس از دریافت بسته بازار، نمودار به‌صورت خودکار رسم می‌شود.",
                          fill="#8b9aaa", font=("Segoe UI", 9))
            return
        visible = bars[-min(90, len(bars)):]
        lo = min(x["low"] for x in visible)
        hi = max(x["high"] for x in visible)
        span = max(hi-lo, 1e-8)
        top, bottom = pad_t, h-pad_b
        plot_h = bottom-top
        def yy(v): return bottom - (v-lo)/span*plot_h
        for k in range(5):
            val = lo + span*k/4
            y = yy(val)
            c.create_line(pad_l, y, w-pad_r, y, fill="#293744", dash=(2, 4))
            c.create_text(pad_l-7, y, text=f"{val:.2f}", fill="#9fb0c0",
                          anchor="e", font=("Segoe UI", 8))
        step = (w-pad_l-pad_r)/max(1, len(visible))
        body_w = max(3, min(10, step*0.62))
        for i, b in enumerate(visible):
            x = pad_l + (i+0.5)*step
            yo, yc, yh, yl = yy(b["open"]), yy(b["close"]), yy(b["high"]), yy(b["low"])
            color = "#20c997" if b["close"] >= b["open"] else "#ef5368"
            c.create_line(x, yh, x, yl, fill=color, width=1)
            c.create_rectangle(x-body_w/2, min(yo, yc), x+body_w/2,
                               max(min(yo, yc)+1, max(yo, yc)), fill=color, outline=color)
        c.create_text(pad_l, 8, text=f'{snap.get("symbol","")}  {snap.get("timeframe","")}',
                      fill="#dce6ef", anchor="nw", font=("Segoe UI", 9, "bold"))
        if snap.get("price") is not None:
            y = yy(snap["price"])
            c.create_line(pad_l, y, w-pad_r, y, fill="#e4b94b", dash=(5, 3))
            c.create_text(w-pad_r-3, max(12, y-10), text=f'{snap["price"]:.2f}',
                          fill="#f1c75b", anchor="e", font=("Segoe UI", 8, "bold"))
        c.create_text(pad_l, h-8, text=visible[0].get("time", "")[-8:],
                      fill="#8293a3", anchor="sw", font=("Segoe UI", 8))
        c.create_text(w-pad_r, h-8, text=visible[-1].get("time", "")[-8:],
                      fill="#8293a3", anchor="se", font=("Segoe UI", 8))

    def show_selected_pattern(self, _event=None):
        sel = self.radar.selection()
        if not sel:
            return
        vals = self.radar.item(sel[0], "values")
        self.status.set(f'الگو: {vals[0]} | شباهت: {vals[1]} | آستانه: {vals[2]} | وضعیت: {vals[3]}')

    def on_event(self, kind, text, payload):
        self.root.after(0, lambda: self._append_event(kind, text))

    def _append_event(self, kind, text):
        if not self.root.winfo_exists():
            return
        stamp = time.strftime("%H:%M:%S")
        self.events.insert(0, f"[{stamp}] {kind} | {text}")
        while self.events.size() > 300:
            self.events.delete("end")
        self.status.set(text)

    # ---------------- Image library / region annotation ----------------
    def load_image(self):
        p = filedialog.askopenfilename(filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.webp")])
        if not p:
            return
        self.image_path = Path(p)
        self.selections = []
        self._show_image()
        self.status.set(f"تصویر بارگذاری شد: {self.image_path.name} – محدوده را انتخاب کنید.")

    def _show_image(self):
        if not self.image_path:
            return
        im = Image.open(self.image_path).convert("RGB")
        cw = max(300, self.image_canvas.winfo_width())
        ch = max(250, self.image_canvas.winfo_height())
        self.scale = min((cw-20)/im.width, (ch-20)/im.height, 1.0)
        nw, nh = int(im.width*self.scale), int(im.height*self.scale)
        im = im.resize((nw, nh))
        self.tkimg = ImageTk.PhotoImage(im)
        self.offset = ((cw-nw)//2, (ch-nh)//2)
        self.image_canvas.delete("all")
        self.image_canvas.create_image(*self.offset, anchor="nw", image=self.tkimg)
        self._draw_selections()

    def _coords(self, x, y):
        ox, oy = self.offset
        return ((x-ox)/self.scale, (y-oy)/self.scale)

    def mouse_down(self, e):
        if not self.image_path:
            return
        self.start_pt = self._coords(e.x, e.y)

    def mouse_move(self, e):
        if self.start_pt is None:
            return
        self.image_canvas.delete("preview")
        x0, y0 = self.start_pt
        x1, y1 = self._coords(e.x, e.y)
        self._canvas_shape(x0, y0, x1, y1, "preview")

    def mouse_up(self, e):
        if self.start_pt is None:
            return
        x0, y0 = self.start_pt
        x1, y1 = self._coords(e.x, e.y)
        self.start_pt = None
        im = Image.open(self.image_path)
        x0, x1 = sorted([max(0, min(im.width, x0)), max(0, min(im.width, x1))])
        y0, y1 = sorted([max(0, min(im.height, y0)), max(0, min(im.height, y1))])
        shape = self.shape.get()
        if shape in ("Square", "Circle"):
            side = min(x1-x0, y1-y0)
            x1, y1 = x0+side, y0+side
        if x1-x0 < 12 or y1-y0 < 12:
            self.status.set("محدوده خیلی کوچک است.")
            return
        self.selections.append({"box": [int(x0), int(y0), int(x1), int(y1)], "shape": shape})
        self._draw_selections()
        self.status.set(f"{len(self.selections)} محدوده انتخاب شده است.")

    def _canvas_shape(self, x0, y0, x1, y1, tag):
        ox, oy = self.offset
        a, b = ox+x0*self.scale, oy+y0*self.scale
        c, d = ox+x1*self.scale, oy+y1*self.scale
        shape = self.shape.get()
        if shape in ("Ellipse", "Circle"):
            return self.image_canvas.create_oval(a, b, c, d, outline="#00e5ff", width=2, tags=tag)
        return self.image_canvas.create_rectangle(a, b, c, d, outline="#00e5ff", width=2, tags=tag)

    def _draw_selections(self):
        if not self.image_path:
            return
        self.image_canvas.delete("selection")
        for s in self.selections:
            x0, y0, x1, y1 = s["box"]
            ox, oy = self.offset
            a, b, c, d = ox+x0*self.scale, oy+y0*self.scale, ox+x1*self.scale, oy+y1*self.scale
            if s["shape"] in ("Ellipse", "Circle"):
                self.image_canvas.create_oval(a, b, c, d, outline="#00ff9d", width=2, tags="selection")
            else:
                self.image_canvas.create_rectangle(a, b, c, d, outline="#00ff9d", width=2, tags="selection")

    def undo(self):
        if self.selections:
            self.selections.pop()
            self._draw_selections()

    def save(self):
        if not self.image_path or not self.selections:
            messagebox.showwarning("Pattern Hunter", "ابتدا تصویر و حداقل یک محدوده انتخاب کنید.")
            return
        for i, s in enumerate(self.selections, 1):
            win = tk.Toplevel(self.root)
            win.title(f"مشخصات الگو {i}")
            win.grab_set()
            name = tk.StringVar(value=f"Pattern {int(time.time())}_{i}")
            direction = tk.StringVar(value="ANY")
            threshold = tk.StringVar(value="50")
            ttk.Label(win, text="نام الگو").pack(padx=12, pady=(12, 2))
            ttk.Entry(win, textvariable=name, width=34).pack(padx=12)
            ttk.Label(win, text="جهت").pack(padx=12, pady=(8, 2))
            ttk.Combobox(win, textvariable=direction, values=["ANY", "BUY", "SELL"],
                         state="readonly").pack(padx=12)
            ttk.Label(win, text="حداقل شباهت (درصد)").pack(padx=12, pady=(8, 2))
            ttk.Entry(win, textvariable=threshold).pack(padx=12)
            def commit(s=s, name=name, direction=direction, threshold=threshold, win=win):
                try:
                    th = float(threshold.get())
                except ValueError:
                    messagebox.showerror("خطا", "درصد باید عددی باشد.")
                    return
                if not 1 <= th <= 100:
                    messagebox.showerror("خطا", "درصد باید بین 1 تا 100 باشد.")
                    return
                self._save_pattern(s, name.get(), direction.get(), th)
                win.destroy()
            ttk.Button(win, text="ثبت در کتابخانه", command=commit).pack(pady=12)
            self.root.wait_window(win)
        self.status.set("ثبت محدوده‌ها انجام شد؛ الگوها برای اسکن زنده در دسترس هستند.")
        self.refresh_library_list()

    def _save_pattern(self, s, name, direction, threshold):
        pid = "P" + uuid.uuid4().hex[:8].upper()
        folder = ROOT/"Library"/pid
        folder.mkdir(parents=True, exist_ok=True)
        shutil.copy2(self.image_path, folder/("original"+self.image_path.suffix.lower()))
        x1, y1, x2, y2 = s["box"]
        im = cv2.imread(str(self.image_path))
        crop = im[y1:y2, x1:x2]
        cv2.imwrite(str(folder/"selected_region.png"), crop)
        mask = np.zeros(crop.shape[:2], np.uint8)
        if s["shape"] in ("Ellipse", "Circle"):
            cv2.ellipse(mask, (mask.shape[1]//2, mask.shape[0]//2),
                        (max(1, mask.shape[1]//2), max(1, mask.shape[0]//2)), 0, 0, 360, 255, -1)
        else:
            mask[:] = 255
        cv2.imwrite(str(folder/"region_mask.png"), mask)
        desc = image_descriptor(self.image_path, s["box"])
        seq = image_candle_sequence(self.image_path, s["box"], s["shape"])
        desc["bar_count"] = len(seq) if seq else 0
        desc["sequence_proxy"] = seq
        desc["matching_ready"] = bool(seq and len(seq) >= 5)
        meta = {"id": pid, "name": name, "direction": direction, "shape": s["shape"],
                "box": s["box"], "threshold": threshold, "symbol": "XAUUSD",
                "timeframe": "M1", "descriptor": desc,
                "validation": "APPROXIMATE_IMAGE_CANDLE_EXTRACTION"}
        (folder/"metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        self.engine.store.add_pattern({
            "id": pid, "name": name,
            "image_path": str(folder/("original"+self.image_path.suffix.lower())),
            "crop_path": str(folder/"selected_region.png"),
            "mask_path": str(folder/"region_mask.png"), "shape": s["shape"],
            "box": s["box"], "direction": direction, "threshold": threshold,
            "descriptor": desc
        })
        self.engine.store.event("LIBRARY_ADD", "XAUUSD", pid, 0,
                                f"Added {name}; extracted candles={len(seq)}; ready={bool(seq and len(seq)>=5)}", meta)
        self._append_event("LIBRARY", f'الگو ذخیره شد: {name} | کندل استخراج‌شده: {len(seq)}')

    def refresh_library_list(self):
        if not hasattr(self, "library_list"):
            return
        self.library_list.delete(0, "end")
        count = 0
        for p in sorted((ROOT/"Library").glob("P*/metadata.json")):
            try:
                m = json.loads(p.read_text(encoding="utf-8"))
                d = m.get("descriptor", {})
                ready = len(d.get("sequence_proxy") or []) >= 5
                state = "آماده اسکن" if ready else "نیازمند اصلاح محدوده"
                self.library_list.insert("end",
                    f'{m.get("id")} | {m.get("name")} | {len(d.get("sequence_proxy") or [])} کندل | {state}')
                count += 1
            except Exception:
                continue
        self.status.set(f"کتابخانه بازخوانی شد: {count} الگو")

    def close(self):
        self.engine.stop()
        self.root.destroy()


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
