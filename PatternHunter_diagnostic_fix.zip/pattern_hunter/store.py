import sqlite3, json, time
from pathlib import Path

class Store:
    def __init__(self, root):
        self.root=Path(root)
        self.db=self.root/"pattern_hunter.db"
        self.conn=sqlite3.connect(self.db, check_same_thread=False)
        self.conn.execute("""CREATE TABLE IF NOT EXISTS patterns(
            id TEXT PRIMARY KEY, name TEXT, image_path TEXT, crop_path TEXT, mask_path TEXT,
            shape TEXT, box TEXT, direction TEXT, threshold REAL, enabled INTEGER,
            descriptor TEXT, created REAL)""")
        self.conn.execute("""CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, kind TEXT, symbol TEXT,
            pattern_id TEXT, score REAL, message TEXT, payload TEXT)""")
        self.conn.commit()

    def add_pattern(self, p):
        self.conn.execute("""INSERT OR REPLACE INTO patterns VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (p["id"],p["name"],p["image_path"],p["crop_path"],p["mask_path"],p["shape"],
             json.dumps(p["box"]),p["direction"],p["threshold"],1,
             json.dumps(p["descriptor"]),time.time()))
        self.conn.commit()

    def patterns(self):
        rows=self.conn.execute("SELECT id,name,image_path,crop_path,mask_path,shape,box,direction,threshold,enabled,descriptor FROM patterns WHERE enabled=1").fetchall()
        keys=["id","name","image_path","crop_path","mask_path","shape","box","direction","threshold","enabled","descriptor"]
        out=[]
        for r in rows:
            p=dict(zip(keys,r)); p["box"]=json.loads(p["box"]); p["descriptor"]=json.loads(p["descriptor"]); out.append(p)
        return out

    def event(self, kind, symbol="", pattern_id="", score=0, message="", payload=None):
        self.conn.execute("INSERT INTO events(ts,kind,symbol,pattern_id,score,message,payload) VALUES(?,?,?,?,?,?,?)",
            (time.time(),kind,symbol,pattern_id,float(score),message,json.dumps(payload or {})))
        self.conn.commit()

    def recent_events(self, limit=100):
        return self.conn.execute("SELECT ts,kind,symbol,pattern_id,score,message FROM events ORDER BY id DESC LIMIT ?",(limit,)).fetchall()
