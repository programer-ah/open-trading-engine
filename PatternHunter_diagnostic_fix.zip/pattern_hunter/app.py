import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
from pathlib import Path
import shutil, uuid, json, logging, time
import cv2, numpy as np
from .features import image_descriptor, image_candle_sequence
from .engine import Engine

ROOT=Path(__file__).resolve().parent.parent
(ROOT/"Library").mkdir(exist_ok=True); (ROOT/"logs").mkdir(exist_ok=True)
logging.basicConfig(filename=ROOT/"logs"/"pattern_hunter.log",level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")

class App:
    def __init__(self, root):
        self.root=root; root.title("Pattern Hunter – Gold Intelligence Engine")
        root.geometry("1120x760"); root.minsize(900,600)
        self.engine=Engine(ROOT,self.on_event)
        self.image_path=None; self.tkimg=None; self.scale=1.0; self.offset=(0,0)
        self.selections=[]; self.start_pt=None; self.preview=None; self.shape=tk.StringVar(value="Rectangle")
        self.status=tk.StringVar(value="آماده – ابتدا تصویر مرجع را وارد کنید.")
        self._build()
        self.engine.start()
        root.protocol("WM_DELETE_WINDOW",self.close)

    def _build(self):
        top=ttk.Frame(self.root,padding=8); top.pack(fill="x")
        ttk.Button(top,text="افزودن تصویر",command=self.load_image).pack(side="left",padx=3)
        ttk.Label(top,text="نوع محدوده:").pack(side="left",padx=(15,3))
        ttk.Combobox(top,textvariable=self.shape,values=["Rectangle","Square","Ellipse","Circle"],state="readonly",width=12).pack(side="left")
        ttk.Button(top,text="حذف آخرین محدوده",command=self.undo).pack(side="left",padx=8)
        ttk.Button(top,text="ذخیره محدوده‌ها",command=self.save).pack(side="left",padx=3)
        ttk.Button(top,text="بازخوانی کتابخانه",command=self.refresh).pack(side="left",padx=3)
        self.canvas=tk.Canvas(self.root,bg="#20242b",highlightthickness=0)
        self.canvas.pack(fill="both",expand=True,padx=8,pady=5)
        self.canvas.bind("<ButtonPress-1>",self.mouse_down)
        self.canvas.bind("<B1-Motion>",self.mouse_move)
        self.canvas.bind("<ButtonRelease-1>",self.mouse_up)
        bottom=ttk.Frame(self.root,padding=8); bottom.pack(fill="x")
        ttk.Label(bottom,textvariable=self.status).pack(side="left",fill="x",expand=True)
        self.events=tk.Listbox(self.root,height=8); self.events.pack(fill="x",padx=8,pady=(0,8))
        self.refresh()

    def load_image(self):
        p=filedialog.askopenfilename(filetypes=[("Images","*.png *.jpg *.jpeg *.bmp *.webp")])
        if not p:return
        self.image_path=Path(p); self.selections=[]
        self._show_image()
        self.status.set(f"تصویر بارگذاری شد: {self.image_path.name} – محدوده را با ماوس انتخاب کنید.")

    def _show_image(self):
        if not self.image_path:return
        im=Image.open(self.image_path).convert("RGB")
        cw=max(300,self.canvas.winfo_width()); ch=max(250,self.canvas.winfo_height())
        self.scale=min((cw-20)/im.width,(ch-20)/im.height,1.0)
        nw,nh=int(im.width*self.scale),int(im.height*self.scale)
        im=im.resize((nw,nh))
        self.tkimg=ImageTk.PhotoImage(im)
        self.offset=((cw-nw)//2,(ch-nh)//2)
        self.canvas.delete("all"); self.canvas.create_image(*self.offset,anchor="nw",image=self.tkimg)
        self._draw_selections()

    def _coords(self,x,y):
        ox,oy=self.offset
        return ((x-ox)/self.scale,(y-oy)/self.scale)

    def mouse_down(self,e):
        if not self.image_path:return
        self.start_pt=self._coords(e.x,e.y)
        self.preview=None

    def mouse_move(self,e):
        if not self.start_pt:return
        self.canvas.delete("preview")
        x0,y0=self.start_pt; x1,y1=self._coords(e.x,e.y)
        self.preview=self._canvas_shape(x0,y0,x1,y1,"preview")

    def mouse_up(self,e):
        if not self.start_pt:return
        x0,y0=self.start_pt; x1,y1=self._coords(e.x,e.y); self.start_pt=None
        x0,x1=sorted([max(0,x0),max(0,x1)]); y0,y1=sorted([max(0,y0),max(0,y1)])
        shape=self.shape.get()
        if shape in ("Square","Circle"):
            side=min(x1-x0,y1-y0); x1=x0+side; y1=y0+side
        if x1-x0<12 or y1-y0<12:
            self.status.set("محدوده خیلی کوچک است."); return
        self.selections.append({"box":[int(x0),int(y0),int(x1),int(y1)],"shape":shape})
        self._draw_selections()
        self.status.set(f"{len(self.selections)} محدوده انتخاب شده است.")

    def _canvas_shape(self,x0,y0,x1,y1,tag):
        ox,oy=self.offset; a=ox+x0*self.scale; b=oy+y0*self.scale
        c=ox+x1*self.scale; d=oy+y1*self.scale
        shape=self.shape.get()
        if shape in ("Ellipse","Circle"):
            return self.canvas.create_oval(a,b,c,d,outline="#00e5ff",width=2,tags=tag)
        return self.canvas.create_rectangle(a,b,c,d,outline="#00e5ff",width=2,tags=tag)

    def _draw_selections(self):
        if not self.image_path:return
        self.canvas.delete("selection")
        for s in self.selections:
            x0,y0,x1,y1=s["box"]; ox,oy=self.offset
            a=ox+x0*self.scale; b=oy+y0*self.scale; c=ox+x1*self.scale; d=oy+y1*self.scale
            if s["shape"] in ("Ellipse","Circle"):
                self.canvas.create_oval(a,b,c,d,outline="#00ff9d",width=2,tags="selection")
            else:self.canvas.create_rectangle(a,b,c,d,outline="#00ff9d",width=2,tags="selection")
    def undo(self):
        if self.selections:self.selections.pop(); self._draw_selections()

    def save(self):
        if not self.image_path or not self.selections:
            messagebox.showwarning("Pattern Hunter","ابتدا تصویر و حداقل یک محدوده انتخاب کنید."); return
        for i,s in enumerate(self.selections,1):
            win=tk.Toplevel(self.root); win.title(f"مشخصات الگو {i}"); win.grab_set()
            name=tk.StringVar(value=f"Pattern {int(time.time())}_{i}")
            direction=tk.StringVar(value="ANY"); threshold=tk.StringVar(value="50")
            ttk.Label(win,text="نام الگو").pack(padx=12,pady=(12,2))
            ttk.Entry(win,textvariable=name,width=34).pack(padx=12)
            ttk.Label(win,text="جهت").pack(padx=12,pady=(8,2))
            ttk.Combobox(win,textvariable=direction,values=["ANY","BUY","SELL"],state="readonly").pack(padx=12)
            ttk.Label(win,text="حداقل شباهت (درصد)").pack(padx=12,pady=(8,2))
            ttk.Entry(win,textvariable=threshold).pack(padx=12)
            def commit(s=s,name=name,direction=direction,threshold=threshold,win=win):
                try: th=float(threshold.get())
                except: messagebox.showerror("خطا","درصد باید عددی باشد."); return
                if not 1<=th<=100: messagebox.showerror("خطا","درصد باید بین 1 تا 100 باشد."); return
                self._save_pattern(s,name.get(),direction.get(),th); win.destroy()
            ttk.Button(win,text="ثبت در کتابخانه",command=commit).pack(pady=12)
            self.root.wait_window(win)
        self.status.set("ثبت محدوده‌ها انجام شد.")
        self.refresh()

    def _save_pattern(self,s,name,direction,threshold):
        pid="P"+uuid.uuid4().hex[:8].upper()
        folder=ROOT/"Library"/pid; folder.mkdir(parents=True,exist_ok=True)
        shutil.copy2(self.image_path,folder/"original"+self.image_path.suffix.lower())
        x1,y1,x2,y2=s["box"]
        im=cv2.imread(str(self.image_path)); crop=im[y1:y2,x1:x2]
        cv2.imwrite(str(folder/"selected_region.png"),crop)
        mask=np.zeros(crop.shape[:2],np.uint8)
        if s["shape"] in ("Ellipse","Circle"):
            cv2.ellipse(mask,(mask.shape[1]//2,mask.shape[0]//2),(max(1,mask.shape[1]//2),max(1,mask.shape[0]//2)),0,0,360,255,-1)
        else: mask[:]=255
        cv2.imwrite(str(folder/"region_mask.png"),mask)
        desc=image_descriptor(self.image_path,s["box"])
        seq=image_candle_sequence(self.image_path,s["box"],s["shape"])
        desc["bar_count"]=len(seq) if seq else 0
        desc["sequence_proxy"]=seq
        desc["matching_ready"]=bool(seq and len(seq)>=5)
        meta={"id":pid,"name":name,"direction":direction,"shape":s["shape"],
              "box":s["box"],"threshold":threshold,"symbol":"XAUUSD","timeframe":"M1",
              "descriptor":desc,"validation":"APPROXIMATE_IMAGE_CANDLE_EXTRACTION"}
        (folder/"metadata.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
        self.engine.store.add_pattern({
            "id":pid,"name":name,"image_path":str(folder/"original"+self.image_path.suffix.lower()),
            "crop_path":str(folder/"selected_region.png"),"mask_path":str(folder/"region_mask.png"),
            "shape":s["shape"],"box":s["box"],"direction":direction,"threshold":threshold,
            "descriptor":desc
        })
        self.engine.store.event("LIBRARY_ADD","XAUUSD",pid,0,
            f"Added {name}; extracted candles={len(seq)}; matching_ready={bool(seq)}",meta)

    def refresh(self):
        self.events.delete(0,"end")
        for p in sorted((ROOT/"Library").glob("P*/metadata.json")):
            try:
                m=json.loads(p.read_text(encoding="utf-8"))
                self.events.insert("end",f'{m["id"]} | {m["name"]} | {m["shape"]} | {m["direction"]} | threshold {m["threshold"]}%')
            except: pass
        for row in self.engine.store.recent_events(25):
            if row[1]!="LIBRARY_ADD": self.events.insert("end",f'{row[1]} | {row[2]} | {row[3]} | {row[5]}')
    def on_event(self,kind,text,payload):
        # Engine callbacks run on worker threads; marshal all Tk updates to the UI thread.
        self.root.after(0,lambda:self._append_event(kind,text))
    def _append_event(self,kind,text):
        self.events.insert(0,f"{kind} | {text}")
        # Keep the event panel bounded during continuous market streaming.
        while self.events.size() > 250:
            self.events.delete("end")
        self.status.set(text)
    def close(self):
        self.engine.stop(); self.root.destroy()

def main():
    root=tk.Tk(); App(root); root.mainloop()
if __name__=="__main__": main()
