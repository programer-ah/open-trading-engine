import json, socket, threading, time, logging
from pathlib import Path
import numpy as np
from .features import live_candle_sequence, dtw_similarity
from .store import Store


class Engine:
    """Receives MT5 OHLC packets, continuously scans saved patterns and exposes UI snapshots."""
    def __init__(self, root, ui_callback=None, host="127.0.0.1", port=8765):
        self.root = Path(root)
        self.store = Store(root)
        self.ui_callback = ui_callback
        self.host, self.port = host, port
        self.running = False
        self.server = None
        self.logger = logging.getLogger("PatternHunter")
        self._lock = threading.RLock()
        self.packet_count = 0
        self.last_market_time = None
        self.last_symbol = None
        self.last_timeframe = None
        self.last_bar_count = 0
        self.last_price = None
        self.last_bid = None
        self.last_ask = None
        self.bars = []
        self.matches = {}
        self.pattern_states = {}
        self.last_telemetry_notice = 0.0
        self.last_scan_time = None

    def notify(self, kind, text, payload=None):
        self.logger.info("%s: %s", kind, text)
        if self.ui_callback:
            try:
                self.ui_callback(kind, text, payload or {})
            except Exception:
                self.logger.exception("UI callback failed")

    def start(self):
        if self.running:
            return
        self.running = True
        threading.Thread(target=self._serve, daemon=True, name="PatternHunterTCP").start()

    def stop(self):
        self.running = False
        try:
            if self.server:
                self.server.close()
        except Exception:
            pass
        try:
            self.store.close()
        except Exception:
            pass

    def snapshot(self):
        with self._lock:
            return {
                "connected": bool(self.packet_count and self.last_market_time),
                "packets": self.packet_count,
                "symbol": self.last_symbol or "-",
                "timeframe": self.last_timeframe or "-",
                "bar_count": self.last_bar_count,
                "price": self.last_price,
                "bid": self.last_bid,
                "ask": self.last_ask,
                "market_time": self.last_market_time,
                "bars": [dict(x) for x in self.bars],
                "matches": [dict(v) for v in sorted(
                    self.matches.values(), key=lambda x: x.get("score", 0), reverse=True)],
                "last_scan_time": self.last_scan_time,
            }

    def _serve(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server = srv
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind((self.host, self.port))
            srv.listen(3)
            srv.settimeout(1)
            self.notify("SYSTEM", f"TCP listener ready at {self.host}:{self.port}")
            while self.running:
                try:
                    conn, addr = srv.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break
                self.notify("SYSTEM", f"MT5 connected: {addr[0]}:{addr[1]}")
                threading.Thread(target=self._client, args=(conn, addr), daemon=True).start()
        except Exception as e:
            self.notify("ERROR", f"Listener error: {e}")
        finally:
            try:
                srv.close()
            except Exception:
                pass

    def _client(self, conn, addr):
        buf = b""
        with conn:
            conn.settimeout(10)
            while self.running:
                try:
                    data = conn.recv(65536)
                except socket.timeout:
                    continue
                except OSError as e:
                    self.notify("ERROR", f"Socket receive error: {e}")
                    break
                if not data:
                    self.notify("SYSTEM", f"MT5 disconnected: {addr[0]}:{addr[1]}")
                    break
                buf += data
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if not line.strip():
                        continue
                    try:
                        self.process_message(json.loads(line.decode("utf-8")))
                    except Exception as e:
                        self.notify("ERROR", f"Bad data packet: {e}")

    def process_message(self, msg):
        if msg.get("type") != "market":
            self.notify("WARNING", f"Unknown packet type: {msg.get('type')}")
            return
        raw_bars = msg.get("bars")
        if not isinstance(raw_bars, list):
            self.notify("WARNING", "Market packet has no valid bars array")
            return
        valid = []
        for b in raw_bars:
            try:
                row = {
                    "time": str(b.get("time", "")),
                    "open": float(b["open"]), "high": float(b["high"]),
                    "low": float(b["low"]), "close": float(b["close"]),
                    "tick_volume": int(b.get("tick_volume", 0))
                }
                if row["high"] >= row["low"] and row["high"] >= max(row["open"], row["close"]) and row["low"] <= min(row["open"], row["close"]):
                    valid.append(row)
            except (KeyError, TypeError, ValueError):
                continue
        if len(valid) < 10:
            now = time.time()
            if now - self.last_telemetry_notice > 5:
                self.last_telemetry_notice = now
                self.notify("WARNING", f"Only {len(valid)} valid candles received")
            return

        symbol = str(msg.get("symbol", "?"))
        timeframe = str(msg.get("timeframe", "?"))
        price = valid[-1]["close"]
        with self._lock:
            self.packet_count += 1
            self.last_market_time = time.strftime("%Y-%m-%d %H:%M:%S")
            self.last_symbol, self.last_timeframe = symbol, timeframe
            self.last_bar_count, self.last_price = len(valid), price
            self.last_bid, self.last_ask = msg.get("bid"), msg.get("ask")
            self.bars = valid[-120:]
            packet_count = self.packet_count
            report = packet_count == 1 or packet_count % 5 == 0

        if report:
            self.notify("MARKET",
                f"دریافت زنده | {symbol} {timeframe} | {len(valid)} کندل | قیمت {price} | بسته {packet_count}",
                {"symbol": symbol, "timeframe": timeframe, "bars": len(valid),
                 "price": price, "packets": packet_count})

        self._scan_patterns(valid, symbol, timeframe, str(msg.get("bar_time", "")))

    def _scan_patterns(self, bars, symbol, timeframe, bar_time):
        # Exclude the still-forming candle: it can change before the next bar closes.
        closed = bars[:-1]
        if len(closed) < 8:
            return
        patterns = self.store.patterns()
        new_matches = {}
        for p in patterns:
            desc = p.get("descriptor") or {}
            ref = desc.get("sequence_proxy") or []
            if len(ref) < 5:
                continue
            ref_len = int(desc.get("bar_count") or len(ref))
            if ref_len < 5 or len(closed) < ref_len:
                continue
            try:
                current = live_candle_sequence(closed[-ref_len:], len(ref))
                reference = np.asarray(ref, dtype=np.float32).reshape(-1, 4)
                score = dtw_similarity(reference, current)
            except Exception as exc:
                self.notify("ERROR", f"Pattern scan failed for {p.get('name')}: {exc}")
                continue
            threshold = float(p.get("threshold", 50))
            match = {
                "id": p["id"], "name": p["name"], "score": round(score, 1),
                "threshold": threshold, "direction": p.get("direction", "ANY"),
                "state": "MATCH" if score >= threshold else "SEARCHING",
                "ready": True, "bar_time": bar_time
            }
            new_matches[p["id"]] = match
            previous = self.pattern_states.get(p["id"], False)
            current_state = score >= threshold
            if current_state and not previous:
                text = f'الگو پیدا شد: {p["name"]} | شباهت {score:.1f}% | {symbol} {timeframe}'
                self.store.event("PATTERN_ENTER", symbol, p["id"], score, text, {"bar_time": bar_time})
                self.notify("PATTERN_ENTER", text, match)
            elif previous and not current_state:
                text = f'خروج از آستانه تطبیق: {p["name"]} | شباهت {score:.1f}%'
                self.store.event("PATTERN_EXIT", symbol, p["id"], score, text, {"bar_time": bar_time})
                self.notify("PATTERN_EXIT", text, match)
            self.pattern_states[p["id"]] = current_state

        # Include saved patterns that cannot currently be scanned, so the UI explains why.
        for p in patterns:
            if p["id"] not in new_matches:
                d = p.get("descriptor") or {}
                reason = "تصویر نیاز به استخراج مجدد دارد" if len(d.get("sequence_proxy") or []) < 5 else "داده کافی نیست"
                new_matches[p["id"]] = {
                    "id": p["id"], "name": p["name"], "score": 0.0,
                    "threshold": float(p.get("threshold", 50)),
                    "direction": p.get("direction", "ANY"),
                    "state": "NOT_READY", "reason": reason, "ready": False
                }
                self.pattern_states[p["id"]] = False
        with self._lock:
            self.matches = new_matches
            self.last_scan_time = time.strftime("%H:%M:%S")
