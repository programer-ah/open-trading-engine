import cv2
import numpy as np

def _resize_gray(img, size=(96, 64)):
    return cv2.resize(img, size, interpolation=cv2.INTER_AREA)

def image_descriptor(path, box):
    """Approximate chart-region descriptor; box is x1,y1,x2,y2 in original pixels."""
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Cannot read image")
    x1,y1,x2,y2 = map(int, box)
    crop = img[max(0,y1):min(img.shape[0],y2), max(0,x1):min(img.shape[1],x2)]
    if crop.size == 0:
        raise ValueError("Empty selection")
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    # Blue and red candle/annotation masks. Kept separate to preserve directional color texture.
    blue = cv2.inRange(hsv, np.array([85,70,60]), np.array([135,255,255]))
    red1 = cv2.inRange(hsv, np.array([0,70,60]), np.array([12,255,255]))
    red2 = cv2.inRange(hsv, np.array([165,70,60]), np.array([180,255,255]))
    red = cv2.bitwise_or(red1, red2)
    # Remove sparse single-pixel noise; do not assume all colored objects are candles.
    blue = cv2.morphologyEx(blue, cv2.MORPH_OPEN, np.ones((2,1), np.uint8))
    red = cv2.morphologyEx(red, cv2.MORPH_OPEN, np.ones((2,1), np.uint8))
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 55, 130)
    channels = []
    for m in (blue, red, edges):
        channels.append((_resize_gray(m).astype(np.float32)/255.0).flatten())
    vec = np.concatenate(channels)
    # Horizontal occupancy captures candle sequence distribution.
    occupancy = []
    for m in (blue, red):
        occupancy.extend((m > 0).mean(axis=0).tolist())
    occ = np.array(occupancy, dtype=np.float32)
    return {"vector": vec.tolist(), "occupancy": occ.tolist(),
            "crop_width": int(crop.shape[1]), "crop_height": int(crop.shape[0])}

def ohlc_descriptor(bars, length=None):
    """Cross-modal descriptor from OHLC: normalized candle body/wicks and returns."""
    rows = bars[-length:] if length else bars
    if len(rows) < 8:
        return None
    arr = np.array([[float(b["open"]), float(b["high"]), float(b["low"]), float(b["close"])]
                    for b in rows], dtype=np.float64)
    scale = max(np.std(arr[:,1]-arr[:,2]), 1e-9)
    mid = (arr[:,1]+arr[:,2])/2
    close = arr[:,3]
    ret = np.diff(close, prepend=close[0]) / scale
    body = (arr[:,3]-arr[:,0]) / scale
    upper = (arr[:,1]-np.maximum(arr[:,0],arr[:,3])) / scale
    lower = (np.minimum(arr[:,0],arr[:,3])-arr[:,2]) / scale
    # Robust clipping makes large spikes informative without dominating.
    feat = np.stack([np.clip(ret,-4,4), np.clip(body,-4,4),
                     np.clip(upper,0,4), np.clip(lower,0,4)], axis=1)
    # Normalize time length for comparison.
    out = cv2.resize(feat.astype(np.float32), (4, 64), interpolation=cv2.INTER_AREA).flatten()
    return out

def cosine_similarity(a, b):
    a=np.asarray(a,dtype=np.float32); b=np.asarray(b,dtype=np.float32)
    n=min(a.size,b.size)
    if n == 0: return 0.0
    a=a[:n]; b=b[:n]
    den=float(np.linalg.norm(a)*np.linalg.norm(b))
    if den < 1e-9: return 0.0
    return float(np.clip(np.dot(a,b)/den, -1, 1))


def image_candle_sequence(path, box, shape):
    """Extract an approximate candle sequence from common light/dark chart themes."""
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Cannot read chart image")
    x1, y1, x2, y2 = map(int, box)
    x1=max(0,x1); y1=max(0,y1); x2=min(img.shape[1],x2); y2=min(img.shape[0],y2)
    crop = img[y1:y2, x1:x2]
    if crop.size == 0:
        return []
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    blue = cv2.inRange(hsv, np.array([85, 55, 45]), np.array([140, 255, 255]))
    red = cv2.bitwise_or(
        cv2.inRange(hsv, np.array([0, 55, 45]), np.array([14, 255, 255])),
        cv2.inRange(hsv, np.array([165, 55, 45]), np.array([180, 255, 255])))
    green = cv2.inRange(hsv, np.array([32, 55, 45]), np.array([90, 255, 255]))

    # White/gray candles are common on dark MT5 templates. Only enable this mask
    # when the crop's border/background is predominantly dark, avoiding white
    # chart backgrounds being interpreted as one giant candle.
    border = np.concatenate([crop[0,:,:], crop[-1,:,:], crop[:,0,:], crop[:,-1,:]], axis=0)
    dark_background = float(np.mean(cv2.cvtColor(border.reshape(-1,1,3), cv2.COLOR_BGR2GRAY))) < 105
    white = np.zeros(crop.shape[:2], np.uint8)
    if dark_background:
        white = cv2.inRange(hsv, np.array([0, 0, 165]), np.array([180, 65, 255]))

    # Blue/green are treated as bullish and red/white as bearish for the
    # common templates used by this project. OHLC comparison itself is color-free.
    bull = cv2.bitwise_or(blue, green)
    bear = cv2.bitwise_or(red, white)
    if shape in ("Ellipse", "Circle"):
        mask = np.zeros(crop.shape[:2], np.uint8)
        cv2.ellipse(mask, (crop.shape[1]//2, crop.shape[0]//2),
                    (max(1,crop.shape[1]//2), max(1,crop.shape[0]//2)),
                    0, 0, 360, 255, -1)
        bull = cv2.bitwise_and(bull, mask)
        bear = cv2.bitwise_and(bear, mask)

    # Thin isolated annotation pixels are removed; vertical wick pixels remain.
    kernel = np.ones((2,1), np.uint8)
    bull = cv2.morphologyEx(bull, cv2.MORPH_OPEN, kernel)
    bear = cv2.morphologyEx(bear, cv2.MORPH_OPEN, kernel)
    active = ((bull > 0) | (bear > 0)).sum(axis=0)
    cols = np.where(active >= 2)[0]
    if len(cols) == 0:
        return []
    groups = []
    start = prev = int(cols[0])
    for col in cols[1:]:
        col = int(col)
        if col-prev > 3:
            groups.append((start, prev+1))
            start = col
        prev = col
    groups.append((start, prev+1))

    seq = []
    for a,b in groups:
        if b-a > 18:
            continue
        bm, rm = bull[:,a:b] > 0, bear[:,a:b] > 0
        ys = np.where(bm | rm)[0]
        if len(ys) < 4:
            continue
        top, bot = float(ys.min()), float(ys.max())
        span = max(1.0, bot-top)
        direction = 1.0 if bm.sum() >= rm.sum() else -1.0
        counts = (bm | rm).sum(axis=1)
        bodyrows = np.where(counts >= max(1, (b-a)//2))[0]
        bt = float(bodyrows.min()) if len(bodyrows) else top
        bb = float(bodyrows.max()) if len(bodyrows) else bot
        seq.append([direction,
                    min(1.0,max(0.0,(bb-bt)/span)),
                    min(1.0,max(0.0,(bt-top)/span)),
                    min(1.0,max(0.0,(bot-bb)/span))])
    return seq[-128:] if len(seq) >= 5 else []

def live_candle_sequence(bars, length):
    out=[]
    for b in bars[-length:]:
        o,h,l,c=map(float,(b["open"],b["high"],b["low"],b["close"]))
        span=max(h-l,1e-9)
        out.append([1.0 if c>=o else -1.0,min(1.0,abs(c-o)/span),
                    min(1.0,max(0.0,(h-max(o,c))/span)),
                    min(1.0,max(0.0,(min(o,c)-l)/span))])
    return np.asarray(out,dtype=np.float32)

def dtw_similarity(a, b, band=10):
    """Constrained DTW distance converted to bounded 0..100 similarity."""
    a=np.asarray(a,dtype=np.float32); b=np.asarray(b,dtype=np.float32)
    if a.ndim == 1: a=a[:,None]
    if b.ndim == 1: b=b[:,None]
    n,m=len(a),len(b)
    if not n or not m: return 0.0
    band=max(band, abs(n-m))
    inf=1e12
    dp=np.full((n+1,m+1),inf,dtype=np.float64); dp[0,0]=0
    for i in range(1,n+1):
        for j in range(max(1,i-band),min(m,i+band)+1):
            cost=float(np.mean((a[i-1]-b[j-1])**2))
            dp[i,j]=cost+min(dp[i-1,j],dp[i,j-1],dp[i-1,j-1])
    dist=float(dp[n,m]/(n+m))
    return float(100.0*np.exp(-2.0*dist))
